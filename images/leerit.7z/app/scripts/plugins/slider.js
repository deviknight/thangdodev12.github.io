//slider on  mobile
;(function($){
  var width = $(window).width();
  if (width < 992) {
    $('.wordbook-list .row').slick({
      dots: false,
      infinite: false,
      speed: 300,
      slidesToShow: 1,
      adaptiveHeight: true
    });
  }
  $(window).resize(function() {
    var w = $(window).width();
    if (w < 992) {
      $('.wordbook-list .row').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
      });
    }
    else {
      $('.wordbook-list .row').slick('unslick');
    }
  });
})(jQuery);
