// footer menu
;(function($){
  var width = $(window).width(),
      icons = {
        header: 'icon icon-bt_up',
        activeHeader: 'icon icon-bt_up'
      };
  if (width < 992) {
    $('#footer-accordion').accordion({
      header: '.link-title',
      heightStyle: 'content',
      icons: icons
    });
    $('#toggle').on('click', function() {
      if ($('#accordion').accordion('option', 'icons')) {
        $('#accordion').accordion('option','icons', null);
      } else {
        $('#accordion').accordion('option', 'icons', icons);
      }
    });
  }
  $(window).resize(function() {
    var w = $(window).width();
    if (w < 992) {
      $('#footer-accordion').accordion({
        header: '.link-title',
        heightStyle: 'content',
        icons: icons
      });
      $('#toggle').on('click', function() {
        if ($('#accordion').accordion('option', 'icons')) {
          $('#accordion').accordion('option','icons', null);
        } else {
          $('#accordion').accordion('option', 'icons', icons);
        }
      });
    }
    else {
      $('#footer-accordion').accordion('destroy');
    }
  });
})(jQuery);
