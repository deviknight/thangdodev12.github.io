//map load more comment
;(function($){
  $('#loadmore').click(function() {
    $('.comment-list').find('li').fadeIn();
    $(this).fadeOut();
  });
})(jQuery);
