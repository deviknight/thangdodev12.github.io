//menu
;(function($){
  $('.navbar-toggle').click(function() {
    $('.navbar-toggle').toggleClass('active');
    $('.navbar-nav').toggleClass('open');
    var h = $(document).height();
    $('.navbar-nav').css('height', h);
  });
  $(window).resize(function() {
    var w = $(window).width();
    if (w >= 992) {
      $('.navbar-nav').css('height','');
    }
    else {
      var h = $(document).height();
      $('.navbar-nav').css('height', h);
    }
  });
})(jQuery);
